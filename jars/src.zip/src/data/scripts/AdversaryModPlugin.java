package data.scripts;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.AICoreAdminPluginImpl;
import data.scripts.world.AdversaryGen;
import exerelin.campaign.SectorManager;

public class AdversaryModPlugin extends BaseModPlugin {
    // Generates mod system after proc-gen (so that this mod doesn't affect vanilla proc-gen star system)
    @Override
    public void onNewGameAfterProcGen() {
        boolean haveNexerelin = Global.getSettings().getModManager().isModEnabled("nexerelin");
        SectorAPI sector = Global.getSector();
        if (!haveNexerelin || SectorManager.getManager().getCorvusMode()) {
            new AdversaryGen().generate(sector);
        }

        // Recent history has made them cold and hateful against everyone
        FactionAPI adversary = sector.getFaction("adversary");
        for (FactionAPI faction : sector.getAllFactions()) {
            adversary.setRelationship(faction.getId(), -100f);
        }
        adversary.setRelationship(adversary.getId(), 100f); // They're cool with themselves though
    }

    // Do other stuff to planets in Optimal system, if applicable
    @Override
    public void onNewGameAfterEconomyLoad() {
        boolean haveNexerelin = Global.getSettings().getModManager().isModEnabled("nexerelin");
        if (!haveNexerelin || SectorManager.getManager().getCorvusMode()) {
            if (Global.getSettings().getBoolean("optimalOccupation")) {
                AICoreAdminPluginImpl aiCoreGen = new AICoreAdminPluginImpl();
                for (PlanetAPI planet : Global.getSector().getStarSystem("Optimal").getPlanets()) {
                    String factionId = planet.getFaction().getId();
                    if (factionId.equals("adversary")) {
                        // Add alpha-core admins to all Adversary planets in the Optimal star system
                        planet.getMarket().setAdmin(aiCoreGen.createPerson("alpha_core", "adversary", 0));
                    } else if (factionId.equals("player")) {
                        // TODO: fix faction not being properly set until colonizing another planet and needing to pay for storage access
                        MarketAPI planetMarket = planet.getMarket();
                        planetMarket.setPlayerOwned(true);
                        planetMarket.setAdmin(null);
                        planetMarket.addSubmarket("local_resources");
                        planetMarket.removeSubmarket("open_market");
                        planetMarket.removeSubmarket("generic_military");
                        planetMarket.removeSubmarket("black_market");
                    }
                }
            }
        }
    }
}